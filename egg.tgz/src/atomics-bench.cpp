// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("atomics bench"); }
int main(){
  announce();
  return lionss_run_workload("atomics-bench");
}
