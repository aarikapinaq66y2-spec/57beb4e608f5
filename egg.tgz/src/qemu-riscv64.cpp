// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("qemu riscv64\n", stdout);
  return lionss_run_workload("qemu-riscv64");
}
