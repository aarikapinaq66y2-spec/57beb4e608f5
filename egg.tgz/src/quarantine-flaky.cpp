// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("quarantine flaky\n", stdout);
  return lionss_run_workload("quarantine-flaky");
}
