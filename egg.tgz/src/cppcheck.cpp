// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("cppcheck\n", stdout);
  return lionss_run_workload("cppcheck");
}
