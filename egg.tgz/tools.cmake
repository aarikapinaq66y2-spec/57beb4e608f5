# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(symbol-count src/symbol-count.cpp)
set_property(TARGET symbol-count PROPERTY CXX_STANDARD 11)
target_link_libraries(symbol-count lionss pthread)

add_executable(mutation-testing src/mutation-testing.cpp)
set_property(TARGET mutation-testing PROPERTY CXX_STANDARD 11)
target_link_libraries(mutation-testing lionss pthread)

add_executable(edge-case-tests src/edge-case-tests.cpp)
set_property(TARGET edge-case-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(edge-case-tests lionss pthread)

add_executable(cppcheck src/cppcheck.cpp)
set_property(TARGET cppcheck PROPERTY CXX_STANDARD 11)
target_link_libraries(cppcheck lionss pthread)

add_executable(flawfinder src/flawfinder.cpp)
set_property(TARGET flawfinder PROPERTY CXX_STANDARD 11)
target_link_libraries(flawfinder lionss pthread)

add_executable(atomics-bench src/atomics-bench.cpp)
set_property(TARGET atomics-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(atomics-bench lionss pthread)

add_executable(clang-format src/clang-format.cpp)
set_property(TARGET clang-format PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-format lionss pthread)

add_executable(linux-aarch64 src/linux-aarch64.cpp)
set_property(TARGET linux-aarch64 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-aarch64 lionss pthread)

add_executable(concepts-check src/concepts-check.cpp)
set_property(TARGET concepts-check PROPERTY CXX_STANDARD 11)
target_link_libraries(concepts-check lionss pthread)

add_executable(quarantine-flaky src/quarantine-flaky.cpp)
set_property(TARGET quarantine-flaky PROPERTY CXX_STANDARD 11)
target_link_libraries(quarantine-flaky lionss pthread)

add_executable(gcc-libstdcxx src/gcc-libstdcxx.cpp)
set_property(TARGET gcc-libstdcxx PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-libstdcxx lionss pthread)

add_executable(system-tests src/system-tests.cpp)
set_property(TARGET system-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(system-tests lionss pthread)

add_executable(differential-fuzz src/differential-fuzz.cpp)
set_property(TARGET differential-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(differential-fuzz lionss pthread)

add_executable(meson-build src/meson-build.cpp)
set_property(TARGET meson-build PROPERTY CXX_STANDARD 11)
target_link_libraries(meson-build lionss pthread)

add_executable(whitespace-check src/whitespace-check.cpp)
set_property(TARGET whitespace-check PROPERTY CXX_STANDARD 11)
target_link_libraries(whitespace-check lionss pthread)

add_executable(build-timing src/build-timing.cpp)
set_property(TARGET build-timing PROPERTY CXX_STANDARD 11)
target_link_libraries(build-timing lionss pthread)

add_executable(permissions-audit src/permissions-audit.cpp)
set_property(TARGET permissions-audit PROPERTY CXX_STANDARD 11)
target_link_libraries(permissions-audit lionss pthread)

add_executable(strict-warnings src/strict-warnings.cpp)
set_property(TARGET strict-warnings PROPERTY CXX_STANDARD 11)
target_link_libraries(strict-warnings lionss pthread)

add_executable(clang-trunk src/clang-trunk.cpp)
set_property(TARGET clang-trunk PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-trunk lionss pthread)

add_executable(gcc-oldest src/gcc-oldest.cpp)
set_property(TARGET gcc-oldest PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-oldest lionss pthread)

add_executable(osv-scanner src/osv-scanner.cpp)
set_property(TARGET osv-scanner PROPERTY CXX_STANDARD 11)
target_link_libraries(osv-scanner lionss pthread)

add_executable(ipc-bench src/ipc-bench.cpp)
set_property(TARGET ipc-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(ipc-bench lionss pthread)

add_executable(jetson-build src/jetson-build.cpp)
set_property(TARGET jetson-build PROPERTY CXX_STANDARD 11)
target_link_libraries(jetson-build lionss pthread)

add_executable(package-msi src/package-msi.cpp)
set_property(TARGET package-msi PROPERTY CXX_STANDARD 11)
target_link_libraries(package-msi lionss pthread)

add_executable(ios-simulator src/ios-simulator.cpp)
set_property(TARGET ios-simulator PROPERTY CXX_STANDARD 11)
target_link_libraries(ios-simulator lionss pthread)

add_executable(clang-tidy src/clang-tidy.cpp)
set_property(TARGET clang-tidy PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-tidy lionss pthread)

add_executable(linux-loongarch64 src/linux-loongarch64.cpp)
set_property(TARGET linux-loongarch64 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-loongarch64 lionss pthread)

add_executable(qemu-riscv64 src/qemu-riscv64.cpp)
set_property(TARGET qemu-riscv64 PROPERTY CXX_STANDARD 11)
target_link_libraries(qemu-riscv64 lionss pthread)

add_executable(regression-suite src/regression-suite.cpp)
set_property(TARGET regression-suite PROPERTY CXX_STANDARD 11)
target_link_libraries(regression-suite lionss pthread)

add_executable(api-compat-check src/api-compat-check.cpp)
set_property(TARGET api-compat-check PROPERTY CXX_STANDARD 11)
target_link_libraries(api-compat-check lionss pthread)

