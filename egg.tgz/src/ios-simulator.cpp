// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("ios simulator\n", stdout);
  return lionss_run_workload("ios-simulator");
}
